X=hello
Z=world

for i in  "$X" "$Y" "$Z"
do
echo --- $i ---
done
