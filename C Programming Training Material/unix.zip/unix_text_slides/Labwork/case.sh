X=pqabqwe
case $X in

ab*) echo case 2
     ;;

qw*) echo case3
     ;;
pq*) echo case 1
     ;;
pqab*) echo case 5
    ;; 
*) echo case 4
     ;;
esac

