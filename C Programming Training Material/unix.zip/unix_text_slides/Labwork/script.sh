#! /bin/bash 
echo hello world
echo Shell id is $$
echo ---- $XY   ----
ps -f 
echo  BYE
AB=hello
echo AB=$AB



