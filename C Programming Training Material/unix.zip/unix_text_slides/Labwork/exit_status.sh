echo hello
ls
exit 100 
